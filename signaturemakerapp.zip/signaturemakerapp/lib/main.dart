import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const SignatureMakerApp());

const Color ink = Color(0xFF172554);
const Color blue = Color(0xFF4F46E5);
const Color cyan = Color(0xFF06B6D4);
const Color pageBg = Color(0xFFF6F8FC);

class SignatureMakerApp extends StatelessWidget {
  const SignatureMakerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Signature Maker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pageBg,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: pageBg,
          foregroundColor: ink,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// SCREEN 1: Splash
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF111C4E), Color(0xFF4338CA), Color(0xFF0891B2)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            const Positioned(top: 90, right: -35, child: GlowCircle(size: 170)),
            const Positioned(bottom: 100, left: -55, child: GlowCircle(size: 210)),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 112,
                    height: 112,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(34),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
                    ),
                    child: const Icon(Icons.draw_rounded, color: Colors.white, size: 60),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Signature Maker',
                    style: TextStyle(color: Colors.white, fontSize: 31, fontWeight: FontWeight.w800, letterSpacing: -0.8),
                  ),
                  const SizedBox(height: 9),
                  Text(
                    'Your name. Your style. Your signature.',
                    style: TextStyle(color: Colors.white.withValues(alpha: 0.82), fontSize: 14),
                  ),
                  const SizedBox(height: 42),
                  const SizedBox(
                    width: 26,
                    height: 26,
                    child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                  ),
                ],
              ),
            ),
            const Positioned(
              bottom: 28,
              left: 0,
              right: 0,
              child: Center(
                child: Text('CREATE  •  CUSTOMIZE  •  SAVE',
                    style: TextStyle(color: Colors.white70, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GlowCircle extends StatelessWidget {
  final double size;
  const GlowCircle({super.key, required this.size});

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: Colors.white.withValues(alpha: 0.06),
      border: Border.all(color: Colors.white.withValues(alpha: 0.08), width: 1.5),
    ),
  );
}

// SCREEN 2: Welcome
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 22, 24, 26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BrandMark(size: 42),
                  const SizedBox(width: 11),
                  const Text('Signature Maker', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: ink)),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(color: const Color(0xFFE8EAFE), borderRadius: BorderRadius.circular(20)),
                    child: const Text('WELCOME', style: TextStyle(color: blue, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
                  ),
                ],
              ),
              const Spacer(),
              Center(
                child: Container(
                  height: 250,
                  width: 250,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: [Color(0xFFE5E9FF), Color(0xFFDDF8FC)]),
                    boxShadow: [BoxShadow(color: blue.withValues(alpha: 0.10), blurRadius: 30, offset: const Offset(0, 15))],
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 178,
                        height: 178,
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(38)),
                        child: const Icon(Icons.draw_rounded, size: 94, color: blue),
                      ),
                      Positioned(
                        right: 28,
                        bottom: 28,
                        child: Container(
                          width: 55,
                          height: 55,
                          decoration: BoxDecoration(color: const Color(0xFF0FBAA7), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white, width: 4)),
                          child: const Icon(Icons.check_rounded, color: Colors.white, size: 28),
                        ),
                      ),
                      const Positioned(top: 30, left: 32, child: Icon(Icons.auto_awesome, color: Color(0xFFF59E0B), size: 28)),
                      const Positioned(top: 58, right: 28, child: Icon(Icons.star_rounded, color: Color(0xFF818CF8), size: 22)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 40),
              const Text('Make it\n'
                  'official.', style: TextStyle(fontSize: 42, height: 1.06, fontWeight: FontWeight.w900, letterSpacing: -1.6, color: ink)),
              const SizedBox(height: 15),
              const Text(
                'Create a signature that feels like you. Draw it by hand, make it personal, and keep your favorite design close.',
                style: TextStyle(fontSize: 15, height: 1.6, color: Color(0xFF64748B)),
              ),
              const SizedBox(height: 25),
              const FeatureLine(icon: Icons.gesture_rounded, text: 'Draw naturally with your finger'),
              const SizedBox(height: 12),
              const FeatureLine(icon: Icons.tune_rounded, text: 'Personalize your signature style'),
              const Spacer(),
              PrimaryButton(
                text: 'Get Started',
                icon: Icons.arrow_forward_rounded,
                onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen())),
              ),
              const SizedBox(height: 14),
              const Center(child: Text('Simple  •  Personal  •  Yours', style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)))),
            ],
          ),
        ),
      ),
    );
  }
}

class BrandMark extends StatelessWidget {
  final double size;
  const BrandMark({super.key, this.size = 44});

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [blue, cyan], begin: Alignment.topLeft, end: Alignment.bottomRight),
      borderRadius: BorderRadius.circular(size * 0.32),
    ),
    child: Icon(Icons.draw_rounded, color: Colors.white, size: size * 0.57),
  );
}

class FeatureLine extends StatelessWidget {
  final IconData icon;
  final String text;
  const FeatureLine({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(color: const Color(0xFFE8EAFE), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, size: 18, color: blue),
      ),
      const SizedBox(width: 11),
      Text(text, style: const TextStyle(fontSize: 13, color: ink, fontWeight: FontWeight.w600)),
    ],
  );
}

class PrimaryButton extends StatelessWidget {
  final String text;
  final IconData? icon;
  final VoidCallback onPressed;
  const PrimaryButton({super.key, required this.text, required this.onPressed, this.icon});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    height: 56,
    child: DecoratedBox(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [blue, Color(0xFF6366F1)]),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: blue.withValues(alpha: 0.23), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            if (icon != null) ...[const SizedBox(width: 9), Icon(icon, size: 19)],
          ],
        ),
      ),
    ),
  );
}

// SCREEN 3: Home
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  SignatureData? savedSignature;
  DateTime? savedAt;

  Future<void> _openCreate() async {
    final result = await Navigator.push<SignatureData>(
      context,
      MaterialPageRoute(builder: (_) => const CreateSignatureScreen()),
    );
    if (result != null && mounted) {
      setState(() {
        savedSignature = result;
        savedAt = DateTime.now();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your signature was saved for this session.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BrandMark(size: 44),
                  const SizedBox(width: 11),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Signature Maker', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink)),
                      SizedBox(height: 2),
                      Text('YOUR PERSONAL SIGNATURE STUDIO', style: TextStyle(fontSize: 8, letterSpacing: 1.1, color: Color(0xFF94A3B8), fontWeight: FontWeight.w700)),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFE8ECF4))),
                    child: IconButton(
                      tooltip: 'About',
                      onPressed: () => showAboutDialog(
                        context: context,
                        applicationName: 'Signature Maker',
                        applicationVersion: '1.0',
                        children: const [Text('Create and save a signature design in a simple mobile interface.')],
                      ),
                      icon: const Icon(Icons.info_outline_rounded, color: ink),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(23),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF171F55), Color(0xFF4338CA), Color(0xFF2563EB)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [BoxShadow(color: blue.withValues(alpha: 0.18), blurRadius: 25, offset: const Offset(0, 12))],
                ),
                child: Stack(
                  children: [
                    const Positioned(right: -12, top: -14, child: Icon(Icons.auto_awesome, size: 75, color: Color(0x337FFFFFFF))),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(30)),
                          child: const Text('✦  SIGNATURE STUDIO', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
                        ),
                        const SizedBox(height: 20),
                        const Text('Your signature,\nyour identity.', style: TextStyle(color: Colors.white, fontSize: 29, height: 1.15, fontWeight: FontWeight.w900, letterSpacing: -0.8)),
                        const SizedBox(height: 10),
                        const Text('Make a mark that is uniquely yours.', style: TextStyle(color: Color(0xFFDDE5FF), fontSize: 13)),
                        const SizedBox(height: 20),
                        SizedBox(
                          height: 47,
                          child: ElevatedButton.icon(
                            onPressed: _openCreate,
                            icon: const Icon(Icons.add_rounded, size: 21),
                            label: const Text('Create Signature', style: TextStyle(fontWeight: FontWeight.w800)),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: blue, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 27),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Explore tools', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: ink)),
                  Text('3 OPTIONS', style: TextStyle(fontSize: 9, letterSpacing: 1.2, color: Colors.blueGrey.shade400, fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: ToolCard(icon: Icons.gesture_rounded, title: 'Draw it', subtitle: 'Freehand', tint: const Color(0xFFE9EAFE), iconColor: blue, onTap: _openCreate)),
                  const SizedBox(width: 11),
                  Expanded(child: ToolCard(icon: Icons.text_fields_rounded, title: 'Type it', subtitle: 'Text styles', tint: const Color(0xFFDDF8F5), iconColor: const Color(0xFF0F9F91), onTap: () => _showComingSoon(context, 'Typed signatures'))),
                  const SizedBox(width: 11),
                  Expanded(child: ToolCard(icon: Icons.palette_outlined, title: 'Style it', subtitle: 'Customize', tint: const Color(0xFFFFF0D9), iconColor: const Color(0xFFD97706), onTap: () => _showComingSoon(context, 'Signature customization'))),
                ],
              ),
              const SizedBox(height: 27),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('My latest signature', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: ink)),
                  if (savedSignature != null) const Icon(Icons.check_circle_rounded, color: Color(0xFF10B981), size: 20),
                ],
              ),
              const SizedBox(height: 13),
              if (savedSignature == null)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 20),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE7EBF3))),
                  child: Column(
                    children: [
                      Container(
                        height: 58,
                        width: 58,
                        decoration: const BoxDecoration(color: Color(0xFFF0F2FF), shape: BoxShape.circle),
                        child: const Icon(Icons.draw_outlined, size: 27, color: blue),
                      ),
                      const SizedBox(height: 12),
                      const Text('No signatures yet', style: TextStyle(color: ink, fontSize: 15, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 5),
                      const Text('Your saved signature will appear here.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
                      const SizedBox(height: 15),
                      TextButton.icon(onPressed: _openCreate, icon: const Icon(Icons.add_rounded), label: const Text('Create your first one')),
                    ],
                  ),
                )
              else
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE7EBF3))),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        height: 100,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: const Color(0xFFFBFCFF), borderRadius: BorderRadius.circular(14)),
                        child: CustomPaint(
                          size: Size.infinite,
                          painter: SignaturePainter(strokes: savedSignature!.strokes, currentStroke: const [], color: savedSignature!.color, strokeWidth: savedSignature!.strokeWidth),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text('Saved ${_formatTime(savedAt)}', style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8))),
                    ],
                  ),
                ),
              const SizedBox(height: 18),
              Container(
                width: width,
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(17)),
                child: const Row(
                  children: [
                    Icon(Icons.lightbulb_outline_rounded, color: Color(0xFF2563EB)),
                    SizedBox(width: 11),
                    Expanded(child: Text('Tip: Draw slowly for a smoother, more natural signature.', style: TextStyle(color: Color(0xFF1E40AF), fontSize: 12, height: 1.4))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String? _formatTime(DateTime? date) {
  if (date == null) return null;
  final h = date.hour % 12 == 0 ? 12 : date.hour % 12;
  final m = date.minute.toString().padLeft(2, '0');
  return '${date.day}/${date.month}/${date.year} • $h:$m ${date.hour >= 12 ? 'PM' : 'AM'}';
}

void _showComingSoon(BuildContext context, String feature) {
  showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      icon: const Icon(Icons.auto_awesome_rounded, color: blue, size: 32),
      title: Text('$feature'),
      content: const Text('This is a planned feature for the next part of the Signature Maker App. The freehand drawing flow is available now.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Got it'))],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    ),
  );
}

class ToolCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color tint;
  final Color iconColor;
  final VoidCallback onTap;
  const ToolCard({super.key, required this.icon, required this.title, required this.subtitle, required this.tint, required this.iconColor, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(19),
    child: InkWell(
      borderRadius: BorderRadius.circular(19),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 17, horizontal: 8),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFE8ECF4))),
        child: Column(
          children: [
            Container(width: 43, height: 43, decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: iconColor, size: 23)),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 12)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 10)),
          ],
        ),
      ),
    ),
  );
}

// SCREEN 4: Create Signature
class CreateSignatureScreen extends StatelessWidget {
  const CreateSignatureScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create signature', style: TextStyle(fontWeight: FontWeight.w900)), leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded))),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('How would you like\nto create it?', style: TextStyle(fontSize: 31, height: 1.15, fontWeight: FontWeight.w900, letterSpacing: -0.8, color: ink)),
              const SizedBox(height: 10),
              const Text('Choose a method to start creating your personal signature.', style: TextStyle(color: Color(0xFF64748B), height: 1.5, fontSize: 14)),
              const SizedBox(height: 27),
              MethodCard(
                icon: Icons.gesture_rounded,
                number: '01',
                title: 'Draw your signature',
                description: 'Use your finger to sign naturally on the canvas.',
                tag: 'AVAILABLE NOW',
                tint: const Color(0xFFE9EAFE),
                iconColor: blue,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DrawSignatureScreen())),
              ),
              const SizedBox(height: 14),
              MethodCard(
                icon: Icons.text_fields_rounded,
                number: '02',
                title: 'Type your signature',
                description: 'Enter your name and turn it into a styled signature.',
                tag: 'COMING NEXT',
                tint: const Color(0xFFDDF8F5),
                iconColor: const Color(0xFF0F9F91),
                onTap: () => _showComingSoon(context, 'Typed signatures'),
              ),
              const SizedBox(height: 14),
              MethodCard(
                icon: Icons.palette_outlined,
                number: '03',
                title: 'Choose a style',
                description: 'Explore a personalized look for your signature.',
                tag: 'COMING NEXT',
                tint: const Color(0xFFFFF0D9),
                iconColor: const Color(0xFFD97706),
                onTap: () => _showComingSoon(context, 'Signature styles'),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFFF0FDF9), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFCCFBF1))),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.verified_user_outlined, color: Color(0xFF0F9F91), size: 22),
                    SizedBox(width: 11),
                    Expanded(child: Text('Your signature is yours. Take your time and create a mark you are happy with.', style: TextStyle(color: Color(0xFF0F766E), height: 1.45, fontSize: 12))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MethodCard extends StatelessWidget {
  final IconData icon;
  final String number;
  final String title;
  final String description;
  final String tag;
  final Color tint;
  final Color iconColor;
  final VoidCallback onTap;
  const MethodCard({super.key, required this.icon, required this.number, required this.title, required this.description, required this.tag, required this.tint, required this.iconColor, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(22),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE7EBF3))),
        child: Row(
          children: [
            Container(width: 57, height: 57, decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(18)), child: Icon(icon, color: iconColor, size: 28)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w900, fontSize: 15)),
                  const SizedBox(height: 5),
                  Text(description, style: const TextStyle(color: Color(0xFF64748B), height: 1.35, fontSize: 11)),
                  const SizedBox(height: 9),
                  Text(tag, style: TextStyle(color: iconColor, fontWeight: FontWeight.w900, fontSize: 8, letterSpacing: 1.1)),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFF94A3B8), size: 16),
          ],
        ),
      ),
    ),
  );
}

// SCREEN 5: Draw Signature
class DrawSignatureScreen extends StatefulWidget {
  const DrawSignatureScreen({super.key});

  @override
  State<DrawSignatureScreen> createState() => _DrawSignatureScreenState();
}

class SignatureData {
  final List<List<Offset>> strokes;
  final Color color;
  final double strokeWidth;
  const SignatureData({required this.strokes, required this.color, required this.strokeWidth});
}

class _DrawSignatureScreenState extends State<DrawSignatureScreen> {
  final List<List<Offset>> _strokes = [];
  List<Offset> _currentStroke = [];
  Color _penColor = const Color(0xFF172554);
  double _strokeWidth = 3.2;
  bool _hasDrawn = false;

  void _startStroke(DragStartDetails details, Size size) {
    setState(() {
      _currentStroke = [details.localPosition];
      _hasDrawn = true;
    });
  }

  void _updateStroke(DragUpdateDetails details) {
    setState(() => _currentStroke.add(details.localPosition));
  }

  void _endStroke(DragEndDetails details) {
    setState(() {
      if (_currentStroke.isNotEmpty) _strokes.add(List<Offset>.from(_currentStroke));
      _currentStroke = [];
    });
  }

  void _undo() {
    if (_strokes.isEmpty && _currentStroke.isEmpty) return;
    setState(() {
      if (_currentStroke.isNotEmpty) {
        _currentStroke = [];
      } else {
        _strokes.removeLast();
      }
      _hasDrawn = _strokes.isNotEmpty || _currentStroke.isNotEmpty;
    });
  }

  void _clear() {
    setState(() {
      _strokes.clear();
      _currentStroke.clear();
      _hasDrawn = false;
    });
  }

  void _save() {
    if (!_hasDrawn || (_strokes.isEmpty && _currentStroke.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Draw your signature before saving.')));
      return;
    }
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        icon: const Icon(Icons.check_circle_rounded, color: Color(0xFF10B981), size: 38),
        title: const Text('Signature saved!'),
        content: const Text('Your signature drawing is ready. It will appear on the Home screen for this app session.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              Navigator.pop(context, SignatureData(strokes: _strokes.map((stroke) => List<Offset>.from(stroke)).toList(), color: _penColor, strokeWidth: _strokeWidth));
            },
            child: const Text('Back to Home'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Draw signature', style: TextStyle(fontWeight: FontWeight.w900)),
        leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
        actions: [
          IconButton(tooltip: 'Undo last stroke', onPressed: _undo, icon: const Icon(Icons.undo_rounded)),
          IconButton(tooltip: 'Clear canvas', onPressed: _clear, icon: const Icon(Icons.delete_outline_rounded)),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 5, 18, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Put your mark on it.', style: TextStyle(color: ink, fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: -0.7)),
              const SizedBox(height: 7),
              const Text('Use your finger to draw inside the white canvas.', style: TextStyle(color: Color(0xFF64748B), fontSize: 13)),
              const SizedBox(height: 18),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(23),
                    border: Border.all(color: const Color(0xFFDDE3F0), width: 1.3),
                    boxShadow: [BoxShadow(color: const Color(0xFF172554).withValues(alpha: 0.04), blurRadius: 20, offset: const Offset(0, 8))],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        return GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onPanStart: (d) => _startStroke(d, Size(constraints.maxWidth, constraints.maxHeight)),
                          onPanUpdate: _updateStroke,
                          onPanEnd: _endStroke,
                          child: Stack(
                            children: [
                              if (!_hasDrawn)
                                const Center(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.gesture_rounded, size: 38, color: Color(0xFFCBD5E1)),
                                      SizedBox(height: 8),
                                      Text('Sign here', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 15, fontWeight: FontWeight.w600)),
                                      SizedBox(height: 4),
                                      Text('Use your finger or stylus', style: TextStyle(color: Color(0xFFCBD5E1), fontSize: 11)),
                                    ],
                                  ),
                                ),
                              CustomPaint(
                                size: Size.infinite,
                                painter: SignaturePainter(strokes: _strokes, currentStroke: _currentStroke, color: _penColor, strokeWidth: _strokeWidth),
                              ),
                              Positioned(
                                left: 18,
                                right: 18,
                                bottom: 45,
                                child: Container(height: 1, color: const Color(0xFFE2E8F0)),
                              ),
                              const Positioned(left: 18, bottom: 20, child: Text('SIGNATURE', style: TextStyle(fontSize: 8, letterSpacing: 2, color: Color(0xFFCBD5E1), fontWeight: FontWeight.w800))),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 17),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFE7EBF3))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('Pen color', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: ink)),
                        const Spacer(),
                        _ColorDot(color: const Color(0xFF172554), selected: _penColor == const Color(0xFF172554), onTap: () => setState(() => _penColor = const Color(0xFF172554))),
                        const SizedBox(width: 10),
                        _ColorDot(color: const Color(0xFF2563EB), selected: _penColor == const Color(0xFF2563EB), onTap: () => setState(() => _penColor = const Color(0xFF2563EB))),
                        const SizedBox(width: 10),
                        _ColorDot(color: const Color(0xFF0F9F91), selected: _penColor == const Color(0xFF0F9F91), onTap: () => setState(() => _penColor = const Color(0xFF0F9F91))),
                        const SizedBox(width: 10),
                        _ColorDot(color: const Color(0xFFDC2626), selected: _penColor == const Color(0xFFDC2626), onTap: () => setState(() => _penColor = const Color(0xFFDC2626))),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Text('Pen thickness', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: ink)),
                        const Spacer(),
                        Text('${_strokeWidth.toStringAsFixed(1)} px', style: const TextStyle(color: Color(0xFF64748B), fontSize: 11)),
                      ],
                    ),
                    Slider(
                      value: _strokeWidth,
                      min: 1.5,
                      max: 7,
                      divisions: 11,
                      activeColor: blue,
                      onChanged: (value) => setState(() => _strokeWidth = value),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _clear,
                      icon: const Icon(Icons.refresh_rounded, size: 18),
                      label: const Text('Clear'),
                      style: OutlinedButton.styleFrom(foregroundColor: ink, side: const BorderSide(color: Color(0xFFDDE3F0)), minimumSize: const Size(0, 52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: SizedBox(
                      height: 52,
                      child: ElevatedButton.icon(
                        onPressed: _save,
                        icon: const Icon(Icons.check_rounded, size: 19),
                        label: const Text('Save signature', style: TextStyle(fontWeight: FontWeight.w800)),
                        style: ElevatedButton.styleFrom(backgroundColor: blue, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ColorDot extends StatelessWidget {
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  const _ColorDot({required this.color, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: selected ? 29 : 25,
      height: selected ? 29 : 25,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: selected ? const Color(0xFFCBD5E1) : Colors.transparent, width: 3),
        boxShadow: selected ? [BoxShadow(color: color.withValues(alpha: 0.25), blurRadius: 7)] : null,
      ),
      child: selected ? const Icon(Icons.check_rounded, size: 14, color: Colors.white) : null,
    ),
  );
}

class SignaturePainter extends CustomPainter {
  final List<List<Offset>> strokes;
  final List<Offset> currentStroke;
  final Color color;
  final double strokeWidth;

  SignaturePainter({required this.strokes, required this.currentStroke, required this.color, required this.strokeWidth});

  @override
  void paint(Canvas canvas, Size size) {
    final guidePaint = Paint()
      ..color = const Color(0xFFF1F5F9)
      ..strokeWidth = 1;
    for (double x = 22; x < size.width; x += 28) {
      for (double y = 20; y < size.height; y += 28) {
        canvas.drawCircle(Offset(x, y), 0.7, guidePaint);
      }
    }

    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    for (final stroke in [...strokes, if (currentStroke.isNotEmpty) currentStroke]) {
      if (stroke.isEmpty) continue;
      if (stroke.length == 1) {
        canvas.drawCircle(stroke.first, strokeWidth / 2, Paint()..color = color);
        continue;
      }
      final path = Path()..moveTo(stroke.first.dx, stroke.first.dy);
      for (int i = 1; i < stroke.length; i++) {
        final point = stroke[i];
        path.lineTo(point.dx, point.dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant SignaturePainter oldDelegate) =>
      oldDelegate.strokes != strokes ||
          oldDelegate.currentStroke != currentStroke ||
          oldDelegate.color != color ||
          oldDelegate.strokeWidth != strokeWidth;
}
